<div class="d-flex justify-content-center pt-2">
    <a href="{{url('/')}}"><img src="{{url('img/logo.png')}}" alt="" width="125px"></a>
</div>
<hr>