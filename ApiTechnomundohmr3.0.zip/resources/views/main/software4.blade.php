<div class="container mb-4">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <a href="{{ url('/pruebaSoftware/create') }}" class="btn btn-danger btn-lg btn-block py-3 px-5">Quiero una prueba GRATIS!!!</a>
        </div>
        <div class="col-md-4"></div>
    </div>
</div>