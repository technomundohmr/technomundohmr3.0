<div class="seccionfoto1">
    <div class="contenido">
        <a href="{{ url('/pruebaSoftware/create') }}">
            <h1>Nuestro compromiso contigo es <strong>-LA SENCILLES-</strong></h1>
            <p>Gestiona tu empresa, con los mejores software del mercado</p>
            <p>tenemos los software más completos y más sencillos de utilizar y los inplementamos en tu empresa.</p>
            <p>Gestiona ventas, inventarios, costos, cartera y mucha más como un profesional.</p>
            <div class="verMas">Ver más <span class="icon-forward"></span></div>
        </a>
    </div>
</div>