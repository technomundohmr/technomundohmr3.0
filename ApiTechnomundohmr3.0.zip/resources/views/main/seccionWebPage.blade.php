<div id="webdesign">
    <div class="imagenParrafo">
        <a href="{{url('/webPage')}}"><img src="img/dise%C3%B1o%20web.jpg" alt="" width="100%" loading="lazy"></a>    
    </div>
    <div class="parrafo">
        <a href="{{url('/webPage')}}">
            <h1>Hacemos tus sueños realidad con el diseño web de tu empresa</h1>
            <p>Creamos páginas web personalizadas, sin plantillas. Así tu página web será única y profesional.</p>
            <p>Tenemos más de una opción para ti, así podrás elegir la que más se adapte a tu negocio y necesidades.</p>
            <div class="verMas">Ver más <span class="icon-forward"></span></div>   
        </a>    
    </div>
</div>