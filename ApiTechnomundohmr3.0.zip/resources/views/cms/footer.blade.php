<footer>
    <div class="bg-secondary w-100 text-center mb-0 mt-5">
        <p class="py-4">Technomundo HMR ©  copyright 2021 | Creado por Technomundo HMR (Andrés Felipe Rincón) </p>
    </div>
</footer>