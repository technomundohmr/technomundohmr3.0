@extends('cms.layout')
@section('content')
    @include('cms.navbar')
    @include('cms.main.buscarAfiliado')
    @include('cms.main.tablaAfiliado')
    @include('cms.footer')
@endsection
