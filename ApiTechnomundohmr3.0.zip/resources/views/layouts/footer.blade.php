<div class="container mt-5">
    <div class="row py-3">
        <div class="col">
            <h2>Haz parte de nuestra familia</h2>
        </div>
    </div>
    <div class="row py-4">
        <div class="col-md-4">
            <h3>Suscribete y recibe noticias y promociones especiales</h3>
        </div>
        <div class="col-md-4">
            @include('cms.marketing.createSuscripcion')
        </div>
        <div class="col-md-4">
            
        </div>
    </div>
</div>
<hr>
<div class="legal">
    <div class="container">
        <div class="row">
            <div class="col-3">
                <p>todos los derechos reservados technomundoHMR <span class="icon-copyright"></span></p>
            </div>
            <div class="col-3">
                <a href="">
                    <p>Nosotros</p>
                </a>
            </div>
            <div class="col-3">
                <a href="https://tienda.technomundohmr.com/privacy-policy/">
                    <p>politica de tratamiento de datos personales</p>
                </a>
            </div>
            <div class="col-3">
                <a href="https://tienda.technomundohmr.com/privacy-policy/">
                    <p>Legal</p>
                </a>
            </div>
        </div>
    </div>
</div>
