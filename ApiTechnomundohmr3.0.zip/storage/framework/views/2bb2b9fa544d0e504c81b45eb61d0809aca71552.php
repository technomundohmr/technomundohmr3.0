
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row my-5">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <a href="" class="btn btn-success btn-lg btn-block">Crear Newsletter</a>
            </div>
            <div class="col-md-4"></div>
        </div>
        <hr>
        <div class="row pt-5">
            <div class="col">
                <h3 class="text-center">Suscripciones</h3>
            </div>
        </div>
        <div class="row my-5">
            <div class="col">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="table-primary">
                            <tr>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Interés</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $correos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($correo->nombre); ?></td>
                                    <td><?php echo e($correo->email); ?></td>
                                    <td><?php echo e($correo->interes); ?></td>
                                    <td>
                                        <form action="<?php echo e(url('/correo/' . $correo->id)); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Borrar')">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/marketing/correos.blade.php ENDPATH**/ ?>