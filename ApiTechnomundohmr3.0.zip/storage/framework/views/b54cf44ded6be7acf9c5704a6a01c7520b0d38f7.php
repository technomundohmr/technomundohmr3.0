
<?php $__env->startSection('title'); ?>
    Technomundo HMR
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <header>
        <?php echo $__env->make('main.logoHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <section class="sticky-top bg-white">
        <?php echo $__env->make('main.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <div class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-10"></div>
                <div class="col-md-2">
                    <form action="<?php echo e(url('/afiliadoLogout')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger">Cerrar Sesion</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            <h1 class="display-5">Bienvenid@ <?php echo e($afiliado->nombre); ?></h1>
            <p class="lead"> > Eres una persona inteligente e importante para nosotros. Solo tienes que compartir tu enlace de afiliado y automáticamente comisionarás el 20% de todo lo que compre tu afiliado.</p>
            <p class="lead"> > Ganate hasta el 10% de las ganancias de tus afiliados por 3 meses!!!</p>
            <hr class="my-4">
            <p>Este es tu enlace de afiliado solo copialo y compartelo.</p>
            <div class="form-group">
                <input type="text" id="enlace" class="form-control" value="<?php echo e(url('/afiliaciones/'.$afiliado->id)); ?>" readonly>
            </div>
            <p class="lead">
                <button class="btn btn-primary btn-lg" id="botonCopy" ><i class="fa fa-copy"></i> Copiar</button>
            </p>
            <div class="alert alert-info alert-dismissible fade show d-none" id="alerta" role="alert">
                Copiado!!!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <h5 class="card-header">Tus datos:</h5>
                    <div class="card-body">
                      <h5 class="card-title"><strong>Nombre: </strong><?php echo e($afiliado->nombre); ?></h5>
                      <p class="card-text"><strong>correo: </strong><?php echo e($afiliado->correo); ?></p>
                      <p class="card-text"><strong>telefono: </strong><?php echo e($afiliado->telefono); ?></p>
                      <p class="card-text"><strong>direccion: </strong><?php echo e($afiliado->direccion); ?></p>
                      <form action="<?php echo e(url('afiliado/'.$afiliado->id.'/edit')); ?>" method="get">
                        <button type="submit" class="btn btn-warning"><i class="fa fa-pencil"></i> Editar</button>
                      </form>
                    </div>
                  </div>    
            </div>
            <div class="col-md-4">
                <div class="card">
                    <h5 class="card-header">Pedir retiro!!</h5>
                    <div class="card-body">
                        <h5 class="card-title"><strong>Metodo de retiro: </strong><?php echo e($afiliado->metodoReembolso); ?></h5>
                        <p class="card-text"><strong>cuenta: </strong><?php echo e($afiliado->cuentaReembolso); ?></p>
                        <p>El reembolso puede tomar hasta 3 dias habiles en verse reflejado</p>
                        <a href="#" class="btn btn-success">Pedir Reembolso</a>
                        <hr>
                        <h4 class="text-center"><strong>saldo: $</strong><?php echo e($afiliado->ganancia); ?></h4>
                    </div>
                  </div>    
            </div>
        </div>
    </div>
    
    <footer>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/afiliado.blade.php ENDPATH**/ ?>