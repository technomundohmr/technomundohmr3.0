<div id="webdesign">
    
    <div class="parrafo">
        <h2 class="text-center">Aprende a hacerla TÚ MISMO!!! SIN PROGRAMAR</h2>
        <p>Si quieres ahorrar un poco y aprender tú mismo a hacer cualqujier pagina web; Este es el producto ideal para ti.</p>
        <p>Este es el curso ideal para ti, pues aprenderás a crear todo lo que puedas necesitar para crear tu sitio web. Tienda virtual, pasarela de pagos, blog pagina prioncipal, etc.</p>
        <p>Pagas y el curso es tuyo.</p>
        <div class="px-5">
            <a href="{{}}" class="btn btn-danger btn-lg btn-block py-4">Quiero recibir mi curso YA!!!</a>
        </div> 
    </div>
    <div class="imagenParrafo">
        <img src="img/aprender.jpg" alt="" width="103%" loading="lazy" class="py-5"></a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/web2.blade.php ENDPATH**/ ?>