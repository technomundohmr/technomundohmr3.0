

<?php $__env->startSection('title'); ?>
    Login Cliente || Technomundo HMR
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header>
    <?php echo $__env->make('main.logoHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<section class="sticky-top bg-white">
    <?php echo $__env->make('main.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
</section>
<div class="container p-5">
    <div class="row">
        <div class="col">
            <?php echo $errors->first('errores','<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Cuidado!</strong> :message
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>'); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4 px-5">
            
            <h1 class="text-center">Hola amigo nuestro</h1>
            <form action="<?php echo e(url('/clienteLogin')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="email" class="form-control" name="correo" id="correo" placeholder="Correo">
                </div>
                <div class="form-group"><input type="password" class="form-control" name="password" id="password" placeholder="contraseña"></div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">Ingresar</button>
            </form>
            <a href="<?php echo e(url('/cliente/create')); ?>" class="my-2 btn btn-danger btn-block btn-lg">Quireo registrarme</a>
        </div>
        <div class="col-md-4"></div>
    </div>
</div>
<footer my-5>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/loginCliente.blade.php ENDPATH**/ ?>