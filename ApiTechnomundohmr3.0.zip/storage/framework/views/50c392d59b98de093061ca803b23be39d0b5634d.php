
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container p-5 my-5">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="<?php echo e(url('/counter')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" class="d-none" value="0" id="visitas" name="visitas">
                    <div class="form-group">
                        <h3 class="text-center">Registrar Nueva Campaña</h3>
                    </div>
                    <div class="form-group">
                        <input type="text" name="origen" id="origen" class="form-control" placeholder="origen">
                    </div>
                    <div class="form-group">
                        <input type="text" name="destino" id="destino" class="form-control" placeholder="destino">
                    </div>
                    <div class="form-group">
                        <input type="text" name="lead" id="lead" class="form-control" placeholder="Campañas">
                    </div>
                    <div class="form-group">
                        <input type="text" name="landing" id="landing" class="form-control" placeholder="URL landing">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-lg btn-block">Guardar</button>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
        <hr>
        <div class="row">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr class="table-primary">
                            <th>
                            <strong>Id</strong>
                            </th>
                            <th>Origen</th>
                            <th>Destino</th>
                            <th>Campaña</th>
                            <th>landing</th>
                            <th>URL para compartir</th>
                            <th>Vistas</th>
                            <th>eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $metricas ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($metrica->id); ?></strong>
                                </td>
                                <td><?php echo e($metrica->origen); ?></td>
                                <td><?php echo e($metrica->destino); ?></td>
                                <td><?php echo e($metrica->lead); ?></td>
                                <td><?php echo e($metrica->landing); ?></td>
                                <td><input type="text" value="<?php echo e(url('/counter/' . $metrica->id)); ?>" readonly></td>
                                <td><?php echo e($metrica->visitas); ?></td>
                                <td>
                                    <form action="<?php echo e(url('/counter/' . $metrica->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger"
                                            onclick="return confirm('Borrar')"><i class="fas fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/crearCounter.blade.php ENDPATH**/ ?>