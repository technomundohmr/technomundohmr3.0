
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col">
                <h3 class="text-center">Main</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="botonCms bg-primary px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/servicios/create')); ?>">
                        <h3><span><i class="fas fa-hand-holding-medical display-3"></i></span> crear servicio</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-danger
                 px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/cotizacionWeb')); ?>">
                        <h3><span><i class="fas fa-network-wired display-3"></i></span> Cotizacion Web</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-info
                 px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/pruebaSoftware')); ?>">
                        <h3><span><i class="fas fa-laptop-code display-3"></i></span> Cotizacion Software</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-warning
                 px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/contacto')); ?>">
                        <h3><span><i class="fas fa-envelope-open-text display-3"></i></span> Contactos</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-success
                 px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/listaAfiliados')); ?>">
                        <h3><span><i class="fas fa-user-friends display-3"></i></span> Afiliados</h3>
                    </a>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col">
                <h3 class="text-center">Marketing</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="botonCms bg-success px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/counter/create')); ?>">
                        <h3><span><i class="fas fa-chart-line display-3"></i></span> visitas</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-info px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/correo')); ?>">
                        <h3><span><i class="fas fa-mail-bulk display-3"></i></span> Correos</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-warning px-3 py-5 text-center m-2">
                    <a href="<?php echo e(url('/suscripcion')); ?>">
                        <h3><span><i class="fas fa-users display-3"></i></span> Suscripciones</h3>
                    </a>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col">
                <h3 class="text-center">Tienda</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="botonCms bg-danger px-3 py-5 text-center m-2">
                    <a href="">
                        <h3><span><i class="fas fa-pallet display-3"></i></span> Productos</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-success px-3 py-5 text-center m-2">
                    <a href="">
                        <h3><span><i class="fas fa-boxes display-3"></i></span> Categorias</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="botonCms bg-primary px-3 py-5 text-center m-2">
                    <a href="">
                        <h3><span><i class="fas fa-truck-moving display-3"></i></span> Pedidos</h3>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/index.blade.php ENDPATH**/ ?>