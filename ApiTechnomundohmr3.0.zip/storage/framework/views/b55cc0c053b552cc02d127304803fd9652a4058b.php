
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo e($contacto -> nombre); ?></th>
                            <th><?php echo e($contacto -> telefono); ?></th>
                            <th><?php echo e($contacto -> correo); ?></th>
                            <th>
                                <form action="<?php echo e(url('/contacto/' . $contacto->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger p-2"
                                        onclick="return confirm('Borrar')"><i
                                            class="fas fa-trash-alt"></i></button>
                                </form>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="4"><?php echo e($contacto -> descripcion); ?></td>
                        </tr>
                    </tbody>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3"></div>
          
        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/contacto.blade.php ENDPATH**/ ?>