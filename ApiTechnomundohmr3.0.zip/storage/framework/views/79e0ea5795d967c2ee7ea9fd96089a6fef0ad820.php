<div class="seccionfoto">
    <div class="contenido">
       <a href="<?php echo e(url('/software')); ?>">
        <h1>Gestiona tu empresa, con los mejores software del mercado</h1>
        <p>tenemos los software más completos y más sencillos de utilizar y los inplementamos en tu empresa.</p>
        <p>Gestiona ventas, inventarios, costos, cartera y mucha más como un profesional.</p>
        <div class="verMas">Ver más <span class="icon-forward"></span></div>   
       </a>
              
    </div>
</div<?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/seccionSoftware.blade.php ENDPATH**/ ?>