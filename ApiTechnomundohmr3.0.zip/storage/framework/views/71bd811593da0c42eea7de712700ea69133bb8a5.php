<div class="container">
    <div class="row my-5">
        <div class="">

        </div>
        <?php $__currentLoopData = $servicios ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4 my-2">
                <div class="card w-100 text-center">
                    <div class="p-3 linkTienda">
                        <a class="linkservicios" href="<?php echo e($servicio->url); ?>" target="_blank">
                            <h3><?php echo e($servicio->titulo); ?></h3>
                            <img src="<?php echo e(asset('storage') . '/' . $servicio->img); ?>" alt="" width="80%" loading="lazy"
                                class="mx-auto">
                            <div class="p-5 text-dark"><?php echo e($servicio->descripcion); ?></div>
                            <div class="display-1">
                                <i class="<?php echo e($servicio->icono); ?>"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/servicios.blade.php ENDPATH**/ ?>