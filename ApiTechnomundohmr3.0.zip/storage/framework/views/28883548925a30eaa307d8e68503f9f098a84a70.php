
<?php $__env->startSection('content'); ?>
<div class="container p-5 my-5">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form action="<?php echo e(url('/sliderMain')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <h3 class="text-center">Insertar Imagen para slider</h3>
                </div>
                <div class="form-group">
                    <input type="text" name="url" id="url" class="form-control" placeholder="Url de destino">
                </div>
                <div class="form-group">
                    <input type="file" name="img" id="img" class="form-control">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-lg">Guardar</button>
                </div>
            </form>
        </div>
        <div class="col-md-4"></div>
    </div>
    <div class="row">
        <table class="table">
            <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $imgs ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="6"><img src="<?php echo e(asset('storage').'/'.$img->img); ?>" alt="" width="80%"></td>
                        <td>
                            <form action="<?php echo e(url('/sliderMain/'.$img->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger px-5 py-3 btn-lg" onclick="return confirm('Borrar')">Borrar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/createSlider.blade.php ENDPATH**/ ?>