
            <div class="table-responsive">
                <table class="table table-bordered ">
                    <thead>
                        <tr >
                            <th class="table-info"><strong>Id</strong></th>
                            <th class="table-primary" >Nombre</th>
                            <th class="table-primary" >Telefono</th>
                            <th class="table-primary" >Correo</th>
                            <th class="table-primary" >Metodo</th>
                            <th class="table-primary" >Cuenta</th>
                            <th class="table-primary" >Saldo</th>
                            <th class="table-primary" ></th>
                            <th class="table-success">Sumar Saldo</th>
                            <th class="table-success"></th>
                            <th class="table-success"></th>
                            <th class="table-danger">Restar Saldo</th>
                            <th class="table-danger"></th>
                            <th class="table-danger"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $afiliados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afiliado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="table-info"><strong><?php echo e($afiliado->id); ?></strong></td>
                            <td><?php echo e($afiliado->nombre); ?></td>
                            <td><?php echo e($afiliado->telefono); ?></td>
                            <td><?php echo e($afiliado->correo); ?></td>
                            <td><?php echo e($afiliado->metodoReembolso); ?></td>
                            <td><?php echo e($afiliado->cuentaReembolso); ?></td>
                            <td colspan="2">$ <?php echo e($afiliado->ganancia); ?></td>
                            <td colspan="3">
                                <form action="<?php echo e(url("listaAfiliados/$afiliado->id")); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PATCH')); ?>

                                    <input type="hidden" id="operacion" name="operacion" value="+">
                                    <div class="form-group">
                                        <input type="number" name="valor" id="valor" placeholder="valor" class="form-control">
                                    </div>
                                    <button type="submit" class="btn btn-success btn-lg ml-4"> + </button>
                                </form>
                            </td>
                            <td colspan="3">
                                <form action="<?php echo e(url("listaAfiliados/$afiliado->id")); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PATCH')); ?>

                                    <input type="hidden" id="operacion" name="operacion" value="-">
                                    <div class="form-group">
                                        <input type="number" name="valor" id="valor" placeholder="valor" class="form-control">
                                    </div>
                                    <button type="submit" class="btn btn-danger btn-lg ml-4"> - </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/tablaAfiliado.blade.php ENDPATH**/ ?>