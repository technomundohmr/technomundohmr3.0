<div id="webdesign">
    
    <div class="imagenParrafo">
        <img class="py-5" src="img/planMensual.jpeg" alt="" width="103%" loading="lazy"></a>
    </div>
    <div class="parrafo">
        <h2 class="text-center">Pregunta por nuestro plan de pagos mensuales</h2>
            <p>Con nuestro plan de pagos mensuales obtienes el mismo servicio con una comoda cuota mensual.</p>
            <p>Sabemos que con la situación actual es difícil invertirle una alta cantidad a nuestro negocio, por eso habilitamos esta facilidad de pago.</p>
            <p>Con un sencillo pago mensual puedes tener tu tienda en linea, terminas de pagar y será completamente tuya.</p>
            <div class="px-5">
                <a href="<?php echo e(url('/cotizacionWeb/create')); ?>" class="btn btn-danger btn-lg btn-block py-4">Quiero recibir mi pagina YA!!!</a>
            </div> 
    </div>
</div><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/planPagos.blade.php ENDPATH**/ ?>