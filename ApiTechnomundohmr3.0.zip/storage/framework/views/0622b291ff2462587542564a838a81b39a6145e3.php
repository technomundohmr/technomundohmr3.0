<nav class="navbar navbar-light bg-info mb-5">
    <a class="navbar-brand px-5" href="<?php echo e(url('/cms/admin')); ?>"><img src="<?php echo e(url('/img/logo.png')); ?>" alt="" width="120px"></a>
<?php if(auth()->guard()->check()): ?>
    <form action="<?php echo e(url('/logout')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <button type="submit" class="btn btn-light">cerrar sesion</button>
    </form>
<?php endif; ?>
</nav><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/navbar.blade.php ENDPATH**/ ?>