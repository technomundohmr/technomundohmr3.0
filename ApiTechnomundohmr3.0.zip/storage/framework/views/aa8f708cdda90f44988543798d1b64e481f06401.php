
<?php $__env->startSection('title'); ?>
    Felicidades
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header>
    <?php echo $__env->make('main.logoHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<section class="sticky-top bg-white">
    <?php echo $__env->make('main.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<hr>
<div class="container my-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="text-center">
                <h1 class="display-3">Felicitaciones</h1>
                <p>Hemos recibido tu solicitud con exito. Pronto nos contactaremos contigo para responder tu solicitud.</p>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-danger btn-lg">Home</a>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>
<footer>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/felicidades.blade.php ENDPATH**/ ?>