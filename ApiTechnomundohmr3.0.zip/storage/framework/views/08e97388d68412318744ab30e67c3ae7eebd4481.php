
<?php $__env->startSection('content'); ?>
    <div class="container p-5 my-5">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="<?php echo e(url('/servicios/'.$servicio->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group">
                        <h3 class="text-center">Editar Servicio <?php echo e($servicio->id); ?></h3>
                    </div>
                    <div class="form-group">
                        <label for="titulo">Titulo</label>
                        <input type="text" name="titulo" id="titulo" class="form-control" value="<?php echo e($servicio->titulo); ?>">
                    </div>
                    <div class="form-group">
                        <label for="icono">Icono</label>
                        <input type="text" name="icono" id="icono" class="form-control" value="<?php echo e($servicio->icono); ?>">
                    </div>
                    <div class="form-group">
                        <label for="url">URL</label>
                        <input type="text" name="url" id="url" class="form-control" value="<?php echo e($servicio->url); ?>">
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripcion</label>
                        <textarea class="form-control" name="descripcion" id="descripcion" cols="30"
                            rows="10"><?php echo e($servicio->descripcion); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Imagen Actual</label>
                        <img src="<?php echo e(asset('storage') . '/' . $servicio->img); ?>" alt="" width="100%" loading="lazy"
                            class="mx-auto">
                    </div>
                    <div class="form-group">
                        <label for="img">Nueva imagen</label>
                        <input type="file" name="img" id="img" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-lg btn-block">Editar</button>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/editServicios.blade.php ENDPATH**/ ?>