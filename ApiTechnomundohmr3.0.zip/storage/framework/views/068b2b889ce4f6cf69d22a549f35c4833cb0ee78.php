
<?php $__env->startSection('title'); ?>
    Quiero mi web YA!!!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header>
    <?php echo $__env->make('main.logoHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<section>
    <?php
        if(isset($_COOKIE['IDafiliado'])){
            $afiliado = $_COOKIE['IDafiliado'];
        }else{
            $afiliado = "no";
        }
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <h1 class="text-center">Al llenar este formulario descargarás un curso gratis para prender a usar el software de POS</h1>
                <h5 class="text-center">Al enviar este formulario un asesor se contactara contigo, por ahora recibirás a tu correo electronico el software y el curso.</h5>
                <form action="<?php echo e(url('/pruebaSoftware')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="text" name="afiliado" id="afiliado" class="form-control" value="<?php echo e($afiliado); ?>" hidden>
                    </div>
                    <div class="form-group">
                        <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" id="email" class="form-control" placeholder="correo" required>
                    </div>
                    <div class="form-group">
                        <label class="peq" for="telefono">Telefono preferiblemente con Whatsapp</label>
                        <input type="text" name="telefono" id="telefono" class="form-control" placeholder="Telefono" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="negocio" id="negocio" class="form-control" placeholder="Que tipo de negocio tienes">
                    </div>
                    <div class="form-group">
                    <input type="text" value="POS" name="solicitado" id="solicitado" hidden>
                    <p class="peq">*Al descargar aceptas nuestras políticas de tratamiento de datos personales*</p>
                    <div class="form-group">
                        <button type="submit" class="btn btn-danger btn-lg btn-block">Descargar curso y prueba gratis!!!</button>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</section>
<footer>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/puebaSoftwareCreate.blade.php ENDPATH**/ ?>