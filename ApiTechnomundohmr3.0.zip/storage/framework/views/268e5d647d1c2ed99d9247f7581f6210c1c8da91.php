<div class="parrafoa my-5">
    <a href="<?php echo e(url('/pruebaSoftware/create')); ?>">
        <div class="container">
            <div class="row my-5">
                <div class="col">
                    <h1 class="text-center">POS Technomundo HMR</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <img src="img/gestion%20simple.jpg" alt="" width="100%" loading="lazy">
                </div>
                <div class="col-md-6">
                    <h3>El software de POS le permitirá manejar se empresa de forma sencilla, intuitiva y completa.</h3>
                    <p>En una empresa es indispensable manejar todos los procesos de forma correcta y organizada, tomando la mayor cantidad de información que sea posible. El software de POS permite guardar información importante de su empresa, de la forma más segura posible.
                        el POS que aprenderás a utilizar a continuación contiene en su interior gestores de bases de datos para; Clientes, Productos, Inventarios, Movimientos, Ventas, salidas, y Opciones de configuración. Este es uno de los programas más fáciles de utilizar, purebalo tú mismo.
                    </p>
                </div>
            </div>
        </div>
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/software2.blade.php ENDPATH**/ ?>