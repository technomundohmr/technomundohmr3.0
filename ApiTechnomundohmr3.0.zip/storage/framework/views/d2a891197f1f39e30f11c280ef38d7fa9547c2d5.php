<div class="d-flex justify-content-center pt-2">
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('img/logo.png')); ?>" alt="" width="125px"></a>
</div>
<hr><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/logoHeader.blade.php ENDPATH**/ ?>