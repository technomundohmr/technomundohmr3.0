
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container p-5 my-5">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="<?php echo e(url('/servicios')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <h3 class="text-center">Nuevo Servicio</h3>
                    </div>
                    <div class="form-group">
                        <input type="text" name="titulo" id="titulo" class="form-control" placeholder="Titulo">
                    </div>
                    <div class="form-group">
                        <input type="text" name="icono" id="icono" class="form-control" placeholder="icono">
                    </div>
                    <div class="form-group">
                        <input type="text" name="url" id="url" class="form-control" placeholder="Url de destino">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="descripcion" id="descripcion" cols="30" rows="10" placeholder="descripcion"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="img">Subir imagen</label>
                        <input type="file" name="img" id="img" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-lg btn-block">Guardar</button>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
        <hr>
        <div class="row">
            <table class="table">
                <thead>
                    <tr class="table-primary">
                        <th>Titulo</th>
                        <th>Descripcion</th>
                        <th></th>
                        <th></th>
                        <th>Icono</th>
                        <th>Imagen</th>
                        <th>url</th>
                        <th>eliminar</th>
                        <th>editar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $servicios ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($servicio->titulo); ?></td>
                            <td colspan="3"><?php echo e($servicio->descripcion); ?></td>
                            <td class="display-3"><i class="<?php echo e($servicio->icono); ?>"></i></td>
                            <td><img src="<?php echo e(asset('storage') . '/' . $servicio->img); ?>" alt="" width="60%" loading="lazy"
                                    class="mx-auto"></td>
                            <td><?php echo e($servicio->url); ?></td>
                            <td>
                                <a href="<?php echo e(url('/servicios/'.$servicio -> id.'/edit')); ?>" class="btn btn-warning btn-lg">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            </td>
                            <td>
                                <form action="<?php echo e(url('/servicios/' . $servicio->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-lg"
                                        onclick="return confirm('Borrar')"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/createServicios.blade.php ENDPATH**/ ?>