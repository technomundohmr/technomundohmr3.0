
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container py-5 my-5">
        <div class="row">
            <div class="col">
                <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card my-3">
                        <div class="card-body">
                            <h5 class="card-title"><strong>Cliente: </strong> <?php echo e($cotizacion->nombre); ?></h5>
                            <ul>
                                <li><strong>Telefono: </strong> <?php echo e($cotizacion->telefono); ?></li>
                                <li><strong>Correo: </strong> <?php echo e($cotizacion->correo); ?></li>
                            </ul>
                            <div class="container ">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="card w-100">
                                            <div class="card-body">

                                                <h5 class="card-title">Negocio: <?php echo e($cotizacion->negocio); ?></h5>
                                                <h5 class="card-title">Descripcion: </h5>
                                                <p class="card-text"><?php echo e($cotizacion->descripcion); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="card w-100">
                                            <div class="card-body">
                                                <h5 class="card-title"><strong>Solicitud: </strong>
                                                    <?php echo e($cotizacion->solicitado); ?></h5>
                                                <h5 class="card-title"> <strong>Medio de pago: </strong> <?php echo e($cotizacion->pago); ?></h5>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">  
                                        <div class="card p-4 w-100">
                                            <form action="<?php echo e(url('/cotizacionWeb/' . $cotizacion->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button type="submit" class="btn btn-danger p-2"
                                                    onclick="return confirm('Borrar')"><i
                                                        class="fas fa-trash-alt display-4"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5 class="card-title my-2"><strong>Afiliado: </strong> <?php echo e($cotizacion->afiliado); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/main/cotizacionWeb.blade.php ENDPATH**/ ?>