<div id="webdesign">
    <div class="imagenParrafo">
        <a href="<?php echo e(url('/servicioTecnico')); ?>"><img src="img/servicio%20tecnico.jpeg" alt="" width="100%" loading="lazy"></a>    
    </div>
    <div class="parrafo">
        <a href="<?php echo e(url('/servicioTecnico')); ?>">
            <h1>¿Te ha fallado tu smarphone o computador?</h1>
            <p>Pregunta por nuestro servicio técnico especializado, dejamos tu computador o smartphone como nuevo</p>
            <p>Recogemos y compramos tus maquina viejas o que ya no necesites. Esperamos dales una nueva vida.</p>
            <div class="verMas">Ver más <span class="icon-forward"></span></div>   
        </a>    
    </div>
</div> <?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/main/seccionServicioTecnico.blade.php ENDPATH**/ ?>