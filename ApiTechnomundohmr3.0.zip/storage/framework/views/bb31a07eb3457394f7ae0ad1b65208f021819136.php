
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container p-5">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <h1 class="text-center">Bienvenido Jefe</h1>
                <form action="<?php echo e(url('/cms/admin/login')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="number" class="form-control" name="identificacion" id="identificacion" placeholder="User">
                    </div>
                    <div class="form-group"><input type="password" class="form-control" name="password" id="password" placeholder="password"></div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg">Login</button>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
    <?php echo $__env->make('cms.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ApiTechnomundohmr3.0\resources\views/cms/login.blade.php ENDPATH**/ ?>