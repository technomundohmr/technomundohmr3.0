<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class servicio_tecnico extends Model
{
    //
}
