<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cotizacionWeb extends Model
{
    //
}
